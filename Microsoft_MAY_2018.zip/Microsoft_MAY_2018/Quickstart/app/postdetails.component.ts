import {Component} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector:`product`,
    template:`<h1> Post Details for {{thePostId}} </h1>
      `
})
export class PostDetailsComponent{

    thePostId:number;
    constructor(currRoute:ActivatedRoute){   
            currRoute.params.subscribe(
                 p=> {
                     this.thePostId = p["id"] // fetch the value
                 }
            )
      }
    
}