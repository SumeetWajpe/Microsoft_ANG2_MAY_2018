import {Component,Input} from '@angular/core';
import { Course } from './course.model';
@Component({
    selector:`course`,
    template:`
    <h1>   {{coursedetails.name | uppercase | lowercase }}</h1>
    <img [src]="coursedetails.imageUrl" height="200px" width="200px" /><br/>
 
    <b> Duration: </b> {{ coursedetails.duration | duration:'hours'}} <br/>
    <b> Location: </b> {{ coursedetails.location}} <br/>
    <b> Date: </b> {{ coursedetails.date}} <br/>
    <b> Price: </b> {{ coursedetails.price | currency:'INR':true }} <br/>    
    <b> Rating: </b> {{ coursedetails.rating | number:'1.1-2' }} <br/>
    <b> RAW Data : </b> {{coursedetails | json }}
    <hr/>
    
    
    `
})
export class CourseComponent{
    @Input('details')    coursedetails:Course=new Course();
}