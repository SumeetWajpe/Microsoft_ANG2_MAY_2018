"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ProductService = (function () {
    function ProductService() {
        this.products = [
            'Mobile', 'TV', 'Laptop', 'Watch'
        ];
    }
    ProductService.prototype.getAllProducts = function () {
        return this.products;
    };
    ProductService.prototype.addNewProduct = function (newProduct) {
        this.products.push(newProduct);
    };
    ProductService.prototype.getRandomProduct = function () {
        return this.products[Math.floor(Math.random()
            * this.products.length)];
    };
    return ProductService;
}());
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map