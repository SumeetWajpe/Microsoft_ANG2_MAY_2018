import {Component} from '@angular/core';
import { ProductService } from './product.service';

@Component({
    selector:`product`,
    template:`<h1> Products </h1>
    <b>{{randomProduct}}</b> <br/>
    <input type="text" [(ngModel)]="newProduct" />
    <input type="button" value="Add" (click)="AddProduct()" />
    <input type="button" value="Get Random Product"    (click)="GetProduct()"   />
    `,    providers:[ProductService]
})
export class ProductComponent{
    randomProduct:string="";
    newProduct:string="";
    constructor(public servObj:ProductService){     }
    GetProduct(){
      this.randomProduct = this.servObj.getRandomProduct()
    }
    AddProduct(){
        this.servObj.addNewProduct(this.newProduct)
    }

}