import { Http } from "@angular/http";
import { Injectable } from "@angular/core";
import 'rxjs/add/operator/toPromise';
@Injectable()
export class PostService{
    constructor(public httpObj:Http){

    }
    // getPosts(callBackFunc:any){
    //     // should get all Posts from server using the url !
    //     this.httpObj.get('https://jsonplaceholder.typicode.com/posts').
    //     subscribe(function(response){
    //         callBackFunc(response.json());
    //     })
    // }
    getPosts(){
      return  this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
        
    }
}