export class ProductService{
    products:string[] = [
        'Mobile','TV','Laptop','Watch'
    ]

    getAllProducts():string[]{
        return this.products;
    }

    addNewProduct(newProduct:string):void{
        this.products.push(newProduct);
    }

    getRandomProduct():string{
        return this.products[Math.floor(Math.random()
             * this.products.length)]
    }
}