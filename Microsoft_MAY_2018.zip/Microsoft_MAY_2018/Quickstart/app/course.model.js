"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Course = (function () {
    function Course(name, duration, location, imageUrl, date, rating, price) {
        this.name = name;
        this.duration = duration;
        this.location = location;
        this.imageUrl = imageUrl;
        this.date = date;
        this.rating = rating;
        this.price = price;
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=course.model.js.map