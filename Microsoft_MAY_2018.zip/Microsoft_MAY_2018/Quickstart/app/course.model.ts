export class Course{
    constructor( public name?:string,
        public duration?:number,
        public location?:string,
        public imageUrl?:string,
        public date?:string,
        public rating?:number,
        public price?:number
    ){

    }
}