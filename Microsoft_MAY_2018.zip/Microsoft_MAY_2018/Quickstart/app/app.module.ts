import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'
import {HttpModule} from '@angular/http';

import {RouterModule,Routes} from '@angular/router';


import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import { DurationPipe } from './duration.pipe';
import { ProductComponent } from './product.component';
import { ProductService } from './product.service';
import { PostComponent } from './post.component';
import { PostDetailsComponent } from './postdetails.component';
import { PostStyleDirective } from './postStyle.directive';


const routes:Routes = [
  {path:'products',component:ProductComponent},
  {path:'posts',component:PostComponent} ,
  {path:'post/:id',component:PostDetailsComponent} 
  ];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,
    RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,
    CourseComponent,PostComponent,
    DurationPipe, PostStyleDirective,
     ProductComponent,PostDetailsComponent ],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
