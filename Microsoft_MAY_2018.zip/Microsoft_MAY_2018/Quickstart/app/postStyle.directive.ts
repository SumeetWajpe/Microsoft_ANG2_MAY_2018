import { Directive, ElementRef, HostListener, OnInit } from "@angular/core";
@Directive({    selector:`[poststyle]`})
export class PostStyleDirective implements OnInit{
        constructor(private refElement:ElementRef){
           }

           ngOnInit(){
            this.refElement.nativeElement.style.backgroundColor = "yellow";
            this.refElement.nativeElement.style.border = "2px solid red";
            this.refElement.nativeElement.style.borderRadius = "10px";
            this.refElement.nativeElement.style.padding = "20px";
            this.refElement.nativeElement.style.margin = "20px";                

           }
      @HostListener('mouseenter')  OnMyMouseEnter(){
        this.refElement.nativeElement.style.backgroundColor = "orange";
        }        
      @HostListener('mouseleave')  OnMyMouseLeave(){
        this.refElement.nativeElement.style.backgroundColor = "yellow";
        }
}