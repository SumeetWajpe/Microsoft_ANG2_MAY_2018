import {Component} from '@angular/core';
import { PostService } from './post.service';


@Component({
    selector:`posts`,
    template:`<h1> Posts </h1>
  
    <ul>
    <li *ngFor="let p of allPosts" poststyle>
       <a [routerLink]="['/post',p.id]"> {{p.title}} </a>
    </li>
    </ul>

    <div poststyle>
    Test Directive !
    </div>
     `,    
     providers:[PostService],
//      styles:[
// `
//         .PostStyle{
//             border:     2px solid red;
//             border-radius: 5px;
//             margin:10px;
//             padding:10px;
//         }
// `

//      ]
})
export class PostComponent{

    allPosts:any = [];
    
    constructor(public servObj:PostService){

        // this.servObj.getPosts((theResponseFromService:any)=>{
        //         console.log('Within Component !');
        //         this.allPosts = theResponseFromService;
        // });


        let aPromise = this.servObj.getPosts();        
        aPromise.then(
            (theReponse)=>{
                    this.allPosts = theReponse.json();
            },
            (theError)=>{
                    console.log('Error : ' + theError)
            });
        // then(success,failure)

         }
  
}