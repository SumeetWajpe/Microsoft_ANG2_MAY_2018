let x = 100;
function Add(x, y) {
    return x + y;
}
