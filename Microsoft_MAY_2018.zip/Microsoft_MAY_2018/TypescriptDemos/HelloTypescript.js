// var x  = 100; // Type Inference !
// x = 200;
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// var str:string; // Type Annotation
// var boolVar:boolean;
// var y:number;
// var anyVar:any;
// anyVar = 1000;
// anyVar = "Hi";
// anyVar = [10,20,30];
// anyVar = {name:'Typescript'};
// // function Square(x:number):number | string {
// //     if(x> 0){
// //     return x *x;        
// //     }
// //     else{
// //         return "x can't be less than 0 !";
// //     }
// // }
// var result:number | string = Square(10);
// console.log(result);
// if(true){
//     let scopedVar:number = 1000; 
//     if(true){
//         let scopedVar = 2000;
//     }
// }
// //console.log(scopedVar)
// const PI =3.14;
// // PI = 3.14565; // Error !
// // Iterating Contructs
// /// JS - for,for-in
// // TS - for-of
// var cars:string[] = ["BMW","AUDI","FERARRI"];
// var moreCars:Array<string> = new Array<string>("TATA","HYUNDAI","MAHINDRA");
// for(let car of cars){
//     console.log(car);
// }
// cars.forEach(function(car){
//     console.log(car);
// });
// // Spread Operator !
// let allCars = [...cars,...moreCars];
// console.log(allCars);
// // Function Parameters - Optional,Default !
// // Optional
// function Add(x?:number,y?:number){
//     return x + y;
// }
// Add();
// Add(10,20);
// // Default Parameters
// // function PrintBooks(author:string="Unknown",title:string="Unknown",noOfPages:number=0){
// // console.log(author,title,noOfPages);
// // }
// //PrintBooks();
// // Rest Parameters
// function PrintBooks(author:string,opt?:string,...titles:string[]){
//         console.log(author);
//         console.log(opt);
//         console.log(titles);
// }
// console.log('-----------------');
// PrintBooks("Dr. APJ Abdul Kalam",undefined,"India 2020","Wings Of Fire")
// console.log('-----------------');
// function GetAllBooks():any[]{
//         return [
//             {title:'Wings Of Fire',author:'Dr. APJ Abdul Kalam',isAvailable:true,price:800},
//             {title:'India 2020',author:'Dr. APJ Abdul Kalam',isAvailable:true,price:600},
//             {title:'Mryuntunjay',author:'Ranjit Desai',isAvailable:true,price:300},
//             {title:'Radhey',author:'Ranjit Desai',isAvailable:true,price:500},
//             {title:'Playing It My Way',author:'Sachin Tendulkar',isAvailable:true,price:1000}
//        ];
// }
// var allBooks:any[] = GetAllBooks();
// for(let book of allBooks){
//     console.log(book.title + " is priced Rs." + book.price)
// }
// // Functions
// // function Square(x:number){
// //     return x * x;
// // }
// // FUnction as an expression
// // var Square = function (x:number){
// //     return x  *x;
// // }
// // Arrow functions
// var Square = (x:number) => x *x;
// cars.forEach(function(car){
//     console.log(car);
// });
// cars.forEach((car:string) => console.log(car));
// function Emp(){
//     this.Salary = 20000;
//     setTimeout(()=>{
//                 console.log(this.Salary);                
//     },2000)
// }
// var e = new Emp();
// interface ICompany{
//     name:string;
//     location:string;
//     isMNC?:boolean;
//     getDetails?():void;
// }
// var company:ICompany = {
//     name:'Microsoft',
// location:'Hyderabad',
// getDetails:function(){
// }
// };
var Car = /** @class */ (function () {
    function Car(theName, theSpeed) {
        if (theName === void 0) { theName = ""; }
        if (theSpeed === void 0) { theSpeed = 0; }
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function () {
        // console.log(this.name + " running at  " + this.speed + " kmph !");
        return (this.name + " running at  " + this.speed + " kmph !");
    };
    return Car;
}());
// var carObj = new Car("i20",200);
// carObj.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(theName, theSpeed, inv, fly) {
        var _this = _super.call(this, theName, theSpeed) || this;
        _this.canBeInvisible = inv;
        _this.canFly = fly;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return " " + _super.prototype.Accelerate.call(this) + " Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 500, true, true);
console.log(jbc.Accelerate());
